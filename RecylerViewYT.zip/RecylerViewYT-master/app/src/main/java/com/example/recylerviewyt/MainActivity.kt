package com.example.recylerviewyt

import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
   lateinit var homeFragment:HomeFragment
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        homeFragment=HomeFragment()
        replaceFragment(homeFragment)

        var btnRemove7 : Button = findViewById<Button>(R.id.btnRemove7)
        btnRemove7.setOnClickListener{
            Log.i("버튼1","")
            homeFragment.click()
        }

    }

    private fun replaceFragment(homeFragment: HomeFragment) {
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.frame_layout,homeFragment)
        fragmentTransaction.commit()
    }

}