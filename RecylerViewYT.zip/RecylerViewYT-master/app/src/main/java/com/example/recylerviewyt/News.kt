package com.example.recylerviewyt

import android.widget.ImageView

data class News(var titleImage : Int, var heading : String ,var image:ImageView?)
